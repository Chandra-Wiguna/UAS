<?php
// Include database connection file
include_once("config.php");

// Variables to store form data and success message
$name = $email = $mobile = $successMessage = $errorMessage = "";

// Check if form submitted, insert form data into users table.
if(isset($_POST['Submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    
    // Insert user data into table
    $result = mysqli_query($mysqli, "INSERT INTO users(name,email,mobile) VALUES('$name','$email','$mobile')");
    
    // Check if the query was successful
    if ($result) {
        $successMessage = "User added successfully.";
    } else {
        $errorMessage = "Failed to add user: " . mysqli_error($mysqli);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Users</title>
    <style>
        /* CSS styles remain the same as before */

        .message-container {
            text-align: center;
            margin-top: 20px;
        }

        .message {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        .options {
            margin-top: 20px;
            text-align: center;
        }

        .options a {
            text-decoration: none;
            display: inline-block;
            margin: 0 10px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .options a.add-another {
            background-color: #333;
            color: #fff;
        }

        .options a.go-home {
            background-color: #555;
            color: #fff;
        }

        .options a:hover {
            background-color: #777;
            color: #fff;
        }
    </style>

    <!-- (JavaScript remains the same as before) -->
</head>

<body>
    <header>
        <h1>Add Users</h1>
    </header>

    <div class="message-container">
        <?php if (!empty($successMessage)): ?>
            <div class="message success-message">
                <?php echo $successMessage; ?>
            </div>
        <?php elseif (!empty($errorMessage)): ?>
            <div class="message error-message">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="options">
        <a href="add.php" class="add-another">Add Another User</a>
        <a href="index.php" class="go-home">Go to Home</a>
    </div>
</body>
</html>
